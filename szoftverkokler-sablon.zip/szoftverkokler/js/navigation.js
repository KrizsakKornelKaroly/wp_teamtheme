(function() {
    const siteNavigation = document.getElementById('site-navigation'); // A <nav> elem
    const menuToggle = document.querySelector('.menu-toggle'); // A hamburger gomb

    // Ellenőrizzük, hogy mindkét elem létezik-e az oldalon
    if (!siteNavigation || !menuToggle) {
        return;
    }

    menuToggle.addEventListener('click', function() {
        // A 'toggled' osztályt kapcsolgatjuk a navigációs elemen
        siteNavigation.classList.toggle('toggled');

        // A gomb 'active' osztályát is kapcsolgatjuk (az X ikonhoz)
        menuToggle.classList.toggle('active');

        // Frissítjük az aria-expanded attribútumot a kisegítő technológiák számára
        const isExpanded = menuToggle.getAttribute('aria-expanded') === 'true' || false;
        menuToggle.setAttribute('aria-expanded', !isExpanded);
    });

    // Opcionális: Almenük kezelése mobil nézetben (kattintásra nyílás)
    // Ez a kód egyelőre csak a főmenü nyitását/csukását kezeli.
    // Ha vannak almenüid (dropdown), azok mobilnézetben történő
    // legördüléséhez további JavaScript logika lehet szükséges,
    // hogy ne hover-re, hanem kattintásra működjenek.
})();