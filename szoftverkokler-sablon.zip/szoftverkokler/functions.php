<?php
/**
 * Alap Sablon funkciók és definíciók
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Alap_Sablon
 */

if ( ! function_exists( 'alap_sablon_setup' ) ) :
    /**
     * Beállítja a sablon alapértelmezéseit és regisztrálja a WordPress funkciók támogatását.
     */
    function alap_sablon_setup() {
        // Fordíthatóvá teszi a sablont.
        load_theme_textdomain( 'alap-sablon', get_template_directory() . '/languages' );

        // Automatikus feed linkek a head-ben.
        add_theme_support( 'automatic-feed-links' );

        // Engedélyezi a Title Tag támogatást.
        // A WordPress kezeli a <title> taget a wp_head() hookon keresztül.
        add_theme_support( 'title-tag' );

        // Engedélyezi a kiemelt képek (Post Thumbnails) támogatását.
        add_theme_support( 'post-thumbnails' );

        // Regisztrál egy nav menü helyet.
        register_nav_menus( array(
            'primary' => esc_html__( 'Elsődleges menü', 'alap-sablon' ),
        ) );

        // Engedélyezi a HTML5 jelölések használatát bizonyos elemekhez.
        add_theme_support( 'html5', array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'style',
            'script',
        ) );

        // Opcionális: Stílusok hozzáadása a vizuális szerkesztőhöz, hogy hasonlítson a frontendhez.
        // add_editor_style( 'editor-style.css' );
    }
endif;
add_action( 'after_setup_theme', 'alap_sablon_setup' );

/**
 * Szkriptek és stílusok hozzáadása (enqueue).
 */
function alap_sablon_scripts() {
    // A fő stíluslap hozzáadása.
    wp_enqueue_style( 'alap-sablon-style', get_stylesheet_uri() );

    // Opcionális: Egyedi JavaScript fájl hozzáadása

      $nav_script_path = get_template_directory() . '/js/navigation.js';
     $nav_script_uri = get_template_directory_uri() . '/js/navigation.js';
 if ( file_exists( $nav_script_path ) ) {
        wp_enqueue_script( 'alap-sablon-navigation', $nav_script_uri, array(), '1.0.1', true );
        // Az array() az esetleges függőségeket tartalmazná (pl. 'jquery')
        // Az utolsó paraméter `true` azt jelenti, hogy a szkript a </body> tag előtt töltődjön be.
        // A '1.0.1' a szkript verziószáma, segít a cache ürítésében frissítéskor.
    }
    // wp_enqueue_script( 'alap-sablon-custom-js', get_template_directory_uri() . '/js/custom.js', array('jquery'), '1.0', true );

    // Hozzászólások válasz szkriptje, ha a hozzászólások engedélyezve vannak és egyedi bejegyzés oldalon vagyunk.
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'alap_sablon_scripts' );

// Opcionális: Widget terület regisztrálása
/*
function alap_sablon_widgets_init() {
    register_sidebar( array(
        'name'          => esc_html__( 'Oldalsáv', 'alap-sablon' ),
        'id'            => 'sidebar-1',
        'description'   => esc_html__( 'Adj hozzá widgeteket ide.', 'alap-sablon' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'alap_sablon_widgets_init' );
*/

?>