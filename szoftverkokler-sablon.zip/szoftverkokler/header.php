<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php wp_title( '|', true, 'right' ); ?> <?php bloginfo( 'name' ); ?></title>
    <?php wp_head(); ?>
    <?php 
        echo '<link rel="preconnect" href="https://fonts.googleapis.com">';
        echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
        echo '<link href="https://fonts.googleapis.com/css2?family=Chakra+Petch:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">'
    ?>
</head>
<body <?php body_class(); ?>>
    <header class="site-header">
        <div class="container header-container fejlec">
            <div class="site-branding">
                <h1 class="oldalCim">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                        <?php
                        $site_icon_url = get_site_icon_url();
                        if ( $site_icon_url ) {
                            echo '<img class="site-title-icon" src="' . esc_url( $site_icon_url ) . '" alt="' . esc_attr__( 'Webhelyikon', 'alap-sablon' ) . '" width="32" height="32">';
                        }
                        ?>
                        <?php bloginfo( 'name' ); ?>
                    </a>
                </h1>
                <?php
                $description = get_bloginfo( 'description', 'display' );
                if ( $description || is_customize_preview() ) : ?>
                    <p class="site-description"><?php echo esc_html( $description ); // esc_html() a biztonságért ?></p>
                <?php endif; ?>
            </div>

            <button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
                <span class="hamburger-icon">&#9776</span>
                <span class="screen-reader-text"><?php esc_html_e( 'Menü', 'alap-sablon' ); ?></span>
            </button>

            <nav id="site-navigation" class="main-navigation">
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'primary',
                    'menu_id'        => 'primary-menu',      // Fontos a JS és aria-controls számára
                    'menu_class'     => 'primary-menu-list', // Osztály a lista stílusozásához
                    'container'      => false,               // Ne csomagolja be plusz div-be
                    'fallback_cb'    => false
                ) );
                ?>
            </nav>
        </div>
    </header>