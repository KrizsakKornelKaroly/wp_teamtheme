<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <title><?php wp_title( '|', true, 'right' ); ?> <?php bloginfo( 'name' ); ?></title>
    <?php wp_head(); ?>
    <?php 
        echo '<link rel="preconnect" href="https://fonts.googleapis.com">';
        echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
        echo '<link href="https://fonts.googleapis.com/css2?family=Chakra+Petch:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">'
    ?>
</head>
<body <?php body_class(); ?>>
    <header>
        <div class="container fejlec">
            <h1 class="oldalCim"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                <?php
                // Lekérjük a webhelyikon URL-jét
                $site_icon_url = get_site_icon_url();
                // Ha van webhelyikon, megjelenítjük
                if ( $site_icon_url ) {
                    // A méretet és az alt szöveget igény szerint állíthatod
                    // Hozzáadhatsz egy CSS osztályt is a további stílusozáshoz (pl. class="site-title-icon")
                    echo '<img src="' . esc_url( $site_icon_url ) . '" alt="' . esc_attr__( 'Webhelyikon', 'alap-sablon' ) . '" width="32" height="32" style="margin-right: 10px; vertical-align: middle;">';
                }
                ?>
                <?php bloginfo( 'name' ); ?>
            </a></h1>
            <p><?php bloginfo( 'description' ); ?></p>
            <nav>
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'primary', // Ezt a functions.php-ban kell regisztrálni
                    'menu_id'        => 'primary-menu',
                    'fallback_cb'    => false // Ne jelenítsen meg semmit, ha nincs menü hozzárendelve
                ) );
                ?>
            </nav>
        </div>
    </header>