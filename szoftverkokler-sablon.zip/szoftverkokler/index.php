<?php get_header(); ?>

<div class="container">
    <main>
        <?php if ( have_posts() ) : ?>
            <?php while ( have_posts() ) : the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <header class="entry-header">
                        <?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
                    </header><div class="entry-content">
                        <?php the_content( __( 'Continue reading<span class="meta-nav">&rarr;</span>', 'alap-sablon' ) ); ?>
                    </div><footer class="entry-footer">
                        <?php if ( comments_open() || get_comments_number() ) :
                            comments_template();
                        endif; ?>
                    </footer></article><?php endwhile; ?>

            <?php
            // Navigáció a bejegyzések között (régebbi/újabb)
            the_posts_navigation(array(
                'prev_text' => __( '&laquo; Régebbi bejegyzések', 'alap-sablon' ),
                'next_text' => __( 'Újabb bejegyzések &raquo;', 'alap-sablon' ),
            ));
            ?>

        <?php else : ?>
            <p><?php _e( 'Sajnos nem található tartalom.', 'alap-sablon' ); ?></p>
        <?php endif; ?>
    </main>
</div>

<?php get_footer(); ?>